### Hexlet tests and linter status:
[![Actions Status](https://github.com/Maxim-Komogortsev/python-project-50/workflows/hexlet-check/badge.svg)](https://github.com/Maxim-Komogortsev/python-project-50/actions)
### CodeClimate:
[![Maintainability](https://api.codeclimate.com/v1/badges/d96946b3127a8e468a98/maintainability)](https://codeclimate.com/github/Maxim-Komogortsev/python-project-50/maintainability)

[![Test Coverage](https://api.codeclimate.com/v1/badges/d96946b3127a8e468a98/test_coverage)](https://codeclimate.com/github/Maxim-Komogortsev/python-project-50/test_coverage)
