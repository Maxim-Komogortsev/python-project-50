from .core import generate_diff


__all__ = (
    'generate_diff',
)